# CQE, Consultorio em Ordem

Reconstrucao do CQE fora do Lovable, mantendo o mesmo banco no Supabase.

## O que tem nesta pasta

Essa e a primeira etapa do plano, o modulo de autenticacao e perfis,
isolado antes de qualquer tela. Ainda nao tem interface, so a base:
cliente do Supabase e o hook que le o perfil do usuario logado.

## Como rodar

1. Copie `.env.example` para `.env` e preencha a chave anon do Supabase
2. `npm install`
3. `npm run dev`

## Proximo passo

Depois que a consulta de schema confirmar os valores reais do banco,
o arquivo `src/features/auth/types/perfil.ts` sera ajustado, e a
proxima pasta a entrar e o painel do super administrador.
